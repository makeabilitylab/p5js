// Some resources
//  - Daniel Shiffman's video series: https://www.youtube.com/watch?v=jmznx0Q1fP0
//  - https://learn.ml5js.org/docs/#/

function setup() {
  createCanvas(640, 480);
  video = createCapture(VIDEO);
  video.hide(); // hide the raw video stream
}

function draw() {
  background(220);
  
  image(video, 0, 0);
}