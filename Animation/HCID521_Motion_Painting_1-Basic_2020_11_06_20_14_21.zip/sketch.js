// A basic motion painting example with randomness
//
// By Jon Froehlich
// http://makeabilitylab.io
// 
// See:
//  - https://medium.com/comsystoreply/introduction-to-p5-js-9a7da09f20aa
//  - https://learning.oreilly.com/library/view/make-getting-started/9781457186769/ch08.html#motion


let x;
let y;
let maxSpeed = 5;
let diameter = 35;


function setup() {
  createCanvas(400, 400);
  x = width / 2; // center of canvas
  y = height / 2; // center of canvas
  background(204);
}

function draw() {
  // we don't call background here, so our previous paintbrush marks stay
  //background(204);
  
  x += random(-maxSpeed, maxSpeed); // gets random value between -5 and 5
  y += random(-maxSpeed, maxSpeed);
  ellipse(x, y, diameter);
}

